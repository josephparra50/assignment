var i = 0
    //This code will begin at 0.
    example = ''
    while (i < 5) {example += i + "<br/>"; i++; }
    //The condition, "(i < 5)", means that as long as the i value is less than 5,
    //it will continue to add 1, as shown by "i++", until i reaches 4, because
    //4 is the last number that is less than 5.
    //The text on the element will now be replaced by the loop code.
    document.getElementById("while_loop").innerHTML = example
    //End of first example
    
    
    //Same goes for vice versa, if the sign was switched to >
    //Here, i has a value of 10. 
    //This code means that it will start at 10, and continuously execute numbers 
    //decreasing by 1, according to "i--", until it reaches 5, where it will stop
    //because the condition says while less than or equal to 5.
    var i = 10 
    example2 = ''
    while (i >= 5) {example2 += i + "<br/>"; i--; }
    document.getElementById("while_loop2").innerHTML = example2
    //End of second example