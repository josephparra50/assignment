    function findSum() {
        //User input to enter two numbers.
        var number1 = parseFloat(prompt("Enter First Number: "));
        var number2 = parseFloat(prompt("Enter Second Number: "));
        //The two numbers from user input are applied to the operation.
        var sum = number1 + number2;
        //To display output on the textarea of the page.
        var answerSum = document.getElementById("result");
        answerSum.textContent = ("SUM: " + sum);
        //To display in JS dialog box.
        alert("The sum is " + sum);

        //The following functions below follow the same or similiar instructions, but with different operations.
    }
    function findDifference() {
        var number1 = parseFloat(prompt("Enter First Number: "));
        var number2 = parseFloat(prompt("Enter Second Number: "));
        var difference = number1 - number2;
        var answerDifference = document.getElementById("result");
        answerDifference.textContent = ("DIFFERENCE: " + difference);
        alert("The difference is " + difference);
    }   
    function findProduct() {
        var number1 = parseInt(prompt("Enter First Number: "));
        var number2 = parseInt(prompt("Enter Second Number: "));
        var product = number1 * number2;
        var answerProduct = document.getElementById("result");
        answerProduct.textContent = ("PRODUCT: " + product);
        alert("The product is " + product);
    }
    function findQuotient() {
        var number1 = parseInt(prompt("Enter First Number: "));
        var number2 = parseInt(prompt("Enter Second Number: "));
        var quotient = number1 / number2;
        var answerQuotient = document.getElementById("result");
        answerQuotient.textContent = ("QUOTIENT: "+ quotient);
        alert("The quotient is " + quotient);
    }
    function findAll() {
        var number1 = parseInt(prompt("Enter First Number"));
        var number2 = parseInt(prompt("Enter Second Number"));
        //All operations to perform on users input.
        var Add = number1 + number2;
        var Sub = number1 - number2;
        var Mul = number1 * number2;
        var Div = number1 / number2;
        //Array to display multiple values on the output.
        var All = ["SUM: " + Add, "DIFFERENCE: " + Sub, "PRODUCT: " + Mul, "QUOTIENT: " + Div];
        var allAnswer = document.getElementById("result");
        allAnswer.textContent = All;
        //For the JS dialog box to display each output seperately.
        alert("The sum is: " + Add);
        alert("The difference is: " + Sub);
        alert("The product is: " + Mul);
        alert("The quotient is: " + Div);
        //The outputs will display addition, subtraction, multiplication, and division, respectively.
    }
    function findSqrt() {
        var number = parseInt(prompt("Enter number to square root: "))
        var square_root = number * number;
        var answerSqrt = document.getElementById("result");
        answerSqrt.textContent = ("Square Root: " + square_root);
        alert("The square root is " + square_root);
    }